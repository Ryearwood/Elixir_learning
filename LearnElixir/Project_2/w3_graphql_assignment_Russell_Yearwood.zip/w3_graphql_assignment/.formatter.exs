[
  import_deps: [:phoenix],
  plugins: [Absinthe.Formatter],
  inputs: ["*.{ex,exs}", "{config,lib,test}/**/*.{ex,exs}"]
]
